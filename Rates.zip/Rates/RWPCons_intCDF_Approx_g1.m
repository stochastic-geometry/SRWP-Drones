function q01 = RWPCons_intCDF_Approx_g1(u0, gam, h, alpha, v, t, MaxN, MeanConstant, WaitConstant)
g10 = @(x) (u0 - x) ./ (1 + 1 / gam * (((u0 - x) .^ 2 + h ^ 2) / h ^ 2) .^ (alpha / 2));
n = MaxN - 1;
R0 = MeanConstant;
T0 = WaitConstant;
if t < T0 %% Wait 0
    q01 = integral(g10, 0, u0);
elseif t < (R0 / v + T0) %% Flight 1
    s = v * t - v * T0;
    if u0 > s
        q01 = integral(g10, s, u0);
    else
        q01 = 0;
    end
elseif t < (R0 / v + T0) + T0 %% Wait 1
    if u0 > R0
        q01 = integral(g10, R0, u0);
    else
        q01 = 0;
    end
elseif t < 2 * (R0 / v + T0) %% Flight 2
    s = v * t - 2 * v * T0 - R0;
    if (u0 <= R0 + s) && (u0 > abs(R0 - s))
        q01 = integral(@(x) g10(x) .* 1 / pi .* acos((R0 ^ 2 + s ^ 2 - x .^ 2) / (2 * R0 * s)), abs(R0 - s), u0);
    elseif u0 > R0 + s
        q01 = integral(@(x) g10(x) .* 1 / pi .* acos((R0 ^ 2 + s ^ 2 - x .^ 2) / (2 * R0 * s)), abs(R0 - s), R0 + s) + integral(g10, R0 + s, u0);
    else
        q01 = 0;
    end
elseif t < 2 * (R0 / v + T0) + T0 %% Wait 2
    if u0 <= 2 * R0
        q01 = integral(@(x) g10(x) .* 2 / pi .* asin(x / (2 * R0)), 0, u0);
    else
        q01 = integral(@(x) g10(x) .* 2 / pi .* asin(x / (2 * R0)), 0, 2 * R0) + integral(g10, 2 * R0, u0);
    end
elseif t < 3 * (R0 / v + T0) %% Flight 3
    s = v * t - 3 * v * T0 - 2 * R0;
    if u0 <= s
        q01 = integral2(@(x, z) g10(x) .* 2 ./ (pi * sqrt((2 * R0) ^ 2 - z .^ 2)) .* 1 / pi .* acos((z .^ 2 + s ^ 2 - x .^ 2) ./ (2 * z * s)), 0, u0, @(x) abs(x - s), @(x) min(x + s, 2 * R0));
    elseif u0 <= 2 * R0 + s
        q01 = integral(@(x) g10(x) .* 2 / pi .* asin((x - s) / (2 * R0)), s, u0) + integral2(@(x, z) g10(x) .* 2 ./ (pi * sqrt((2 * R0) ^ 2 - z .^ 2)) .* 1 / pi .* acos((z .^ 2 + s ^ 2 - x .^ 2) ./ (2 * z * s)), 0, u0, @(x) abs(x - s), @(x) min(x + s, 2 * R0));
    else
        q01 = integral(@(x) g10(x) .* 2 / pi .* asin((x - s) / (2 * R0)), s, 2 * R0 + s) + integral2(@(x, z) g10(x) .* 2 ./ (pi * sqrt((2 * R0) ^ 2 - z .^ 2)) .* 1 / pi .* acos((z .^ 2 + s ^ 2 - x .^ 2) ./ (2 * z * s)), 0, 2 * R0 + s, @(x) abs(x - s), @(x) min(x + s, 2 * R0)) + integral(g10, 2 * R0 + s, u0);
    end
elseif (t >= n * (R0 / v + T0)) && (t < n * (R0 / v + T0) + T0) %% Wait n
    if u0 <= n * R0
        q01 = integral(@(x) g10(x) .* (1 - exp(-x .^ 2 / (n * R0 ^ 2))) / (1 - exp(-n)), 0, u0);
    else
        q01 = integral(@(x) g10(x) .* (1 - exp(-x .^ 2 / (n * R0 ^ 2))) / (1 - exp(-n)), 0, n * R0) + integral(g10, n * R0, u0);
    end
elseif (t >= n * (R0 / v + T0) + T0) && (t < (n + 1) * (R0 / v + T0)) %% Flight n + 1
    s = v * t - (n + 1) * v * T0 - n * R0;
    if u0 <= s
        q01 = integral2(@(x, z) g10(x) .* 2 .* z .* exp(-z .^ 2 / (n * R0 ^ 2)) / (n * R0 ^ 2 * (1 - exp(-n))) .* 1 / pi .* acos((z .^ 2 + s ^ 2 - x .^ 2) ./ (2 * z * s)), 0, u0, @(x) abs(x - s), @(x) min(x + s, n * R0));
    elseif u0 <= n * R0 + s
        q01 = integral(@(x) g10(x) .* (1 - exp(-(x - s) .^ 2 / (n * R0 ^ 2))) / (1 - exp(-n)), s, u0) + integral2(@(x, z) g10(x) .* 2 .* z .* exp(-z .^ 2 / (n * R0 ^ 2)) / (n * R0 ^ 2 * (1 - exp(-n))) .* 1 / pi .* acos((z .^ 2 + s ^ 2 - x .^ 2) ./ (2 * z * s)), 0, u0, @(x) abs(x - s), @(x) min(x + s, n * R0));
    else
        q01 = integral(@(x) g10(x) .* (1 - exp(-(x - s) .^ 2 / (n * R0 ^ 2))) / (1 - exp(-n)), s, n * R0 + s) + integral2(@(x, z) g10(x) .* 2 .* z .* exp(-z .^ 2 / (n * R0 ^ 2)) / (n * R0 ^ 2 * (1 - exp(-n))) .* 1 / pi .* acos((z .^ 2 + s ^ 2 - x .^ 2) ./ (2 * z * s)), 0, n * R0 + s, @(x) abs(x - s), @(x) min(x + s, n * R0)) + integral(g10, n * R0 + s, u0);
    end
end