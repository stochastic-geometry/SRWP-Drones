function q01 = RWPCons_intCDF_Approx_g2(u0, gam, h, alpha, v, t, MaxN, MeanConstant, WaitConstant)
g20 = @(x) (u0 - x) ./ (1 + 1 / gam * (((u0 - x) .^ 2 + h ^ 2) / ((u0 - v * t) .^ 2 + h ^ 2)) .^ (alpha / 2));
n = MaxN - 1;
R0 = MeanConstant;
T0 = WaitConstant;
if t < T0 %% Wait 0
    q01 = integral(g20, 0, v * t);
elseif t < (R0 / v + T0) %% Flight 1
    s = v * t - v * T0;
    if v * t > s
        q01 = integral(g20, s, v * t);
    else
        q01 = 0;
    end
elseif t < (R0 / v + T0) + T0 %% Wait 1
    if v * t > R0
        q01 = integral(g20, R0, v * t);
    else
        q01 = 0;
    end
elseif t < 2 * (R0 / v + T0) %% Flight 2
    s = v * t - 2 * v * T0 - R0;
    if (v * t <= R0 + s) && (v * t > abs(R0 - s))
        q01 = integral(@(x) g20(x) .* 1 / pi .* acos((R0 ^ 2 + s ^ 2 - x .^ 2) / (2 * R0 * s)), abs(R0 - s), v * t);
    elseif v * t > R0 + s
        q01 = integral(@(x) g20(x) .* 1 / pi .* acos((R0 ^ 2 + s ^ 2 - x .^ 2) / (2 * R0 * s)), abs(R0 - s), R0 + s) + integral(g20, R0 + s, v * t);
    else
        q01 = 0;
    end
elseif t < 2 * (R0 / v + T0) + T0 %% Wait 2
    if v * t <= 2 * R0
        q01 = integral(@(x) g20(x) .* 2 / pi .* asin(x / (2 * R0)), 0, v * t);
    else
        q01 = integral(@(x) g20(x) .* 2 / pi .* asin(x / (2 * R0)), 0, 2 * R0) + integral(g20, 2 * R0, v * t);
    end
elseif t < 3 * (R0 / v + T0) %% Flight 3
    s = v * t - 3 * v * T0 - 2 * R0;
    if v * t <= s
        q01 = integral2(@(x, z) g20(x) .* 2 ./ (pi * sqrt((2 * R0) ^ 2 - z .^ 2)) .* 1 / pi .* acos((z .^ 2 + s ^ 2 - x .^ 2) ./ (2 * z * s)), 0, v * t, @(x) abs(x - s), @(x) min(x + s, 2 * R0));
    elseif v * t <= 2 * R0 + s
        q01 = integral(@(x) g20(x) .* 2 / pi .* asin((x - s) / (2 * R0)), s, v * t) + integral2(@(x, z) g20(x) .* 2 ./ (pi * sqrt((2 * R0) ^ 2 - z .^ 2)) .* 1 / pi .* acos((z .^ 2 + s ^ 2 - x .^ 2) ./ (2 * z * s)), 0, v * t, @(x) abs(x - s), @(x) min(x + s, 2 * R0));
    else
        q01 = integral(@(x) g20(x) .* 2 / pi .* asin((x - s) / (2 * R0)), s, 2 * R0 + s) + integral2(@(x, z) g20(x) .* 2 ./ (pi * sqrt((2 * R0) ^ 2 - z .^ 2)) .* 1 / pi .* acos((z .^ 2 + s ^ 2 - x .^ 2) ./ (2 * z * s)), 0, 2 * R0 + s, @(x) abs(x - s), @(x) min(x + s, 2 * R0)) + integral(g20, 2 * R0 + s, v * t);
    end
elseif (t >= n * (R0 / v + T0)) && (t < n * (R0 / v + T0) + T0) %% Wait n
    if v * t <= n * R0
        q01 = integral(@(x) g20(x) .* (1 - exp(-x .^ 2 / (n * R0 ^ 2))) / (1 - exp(-n)), 0, v * t);
    else
        q01 = integral(@(x) g20(x) .* (1 - exp(-x .^ 2 / (n * R0 ^ 2))) / (1 - exp(-n)), 0, n * R0) + integral(g20, n * R0, v * t);
    end
elseif (t >= n * (R0 / v + T0) + T0) && (t < (n + 1) * (R0 / v + T0)) %% Flight n + 1
    s = v * t - (n + 1) * v * T0 - n * R0;
    if v * t <= s
        q01 = integral2(@(x, z) g20(x) .* 2 .* z .* exp(-z .^ 2 / (n * R0 ^ 2)) / (n * R0 ^ 2 * (1 - exp(-n))) .* 1 / pi .* acos((z .^ 2 + s ^ 2 - x .^ 2) ./ (2 * z * s)), 0, v * t, @(x) abs(x - s), @(x) min(x + s, n * R0));
    elseif v * t <= n * R0 + s
        q01 = integral(@(x) g20(x) .* (1 - exp(-(x - s) .^ 2 / (n * R0 ^ 2))) / (1 - exp(-n)), s, v * t) + integral2(@(x, z) g20(x) .* 2 .* z .* exp(-z .^ 2 / (n * R0 ^ 2)) / (n * R0 ^ 2 * (1 - exp(-n))) .* 1 / pi .* acos((z .^ 2 + s ^ 2 - x .^ 2) ./ (2 * z * s)), 0, v * t, @(x) abs(x - s), @(x) min(x + s, n * R0));
    else
        q01 = integral(@(x) g20(x) .* (1 - exp(-(x - s) .^ 2 / (n * R0 ^ 2))) / (1 - exp(-n)), s, n * R0 + s) + integral2(@(x, z) g20(x) .* 2 .* z .* exp(-z .^ 2 / (n * R0 ^ 2)) / (n * R0 ^ 2 * (1 - exp(-n))) .* 1 / pi .* acos((z .^ 2 + s ^ 2 - x .^ 2) ./ (2 * z * s)), 0, n * R0 + s, @(x) abs(x - s), @(x) min(x + s, n * R0)) + integral(g20, n * R0 + s, v * t);
    end
end