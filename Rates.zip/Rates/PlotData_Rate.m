%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Fundamentals of Drone Cellular Network Analysis under      %%%
%%%          Random Waypoint Mobility Model                             %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the plot of Fig. 3, average rate    %%%
%%%   in the SRWP mobility model.                                       %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rVec_Simulation = (0 : 276).';
rVec_Theory = [4 : 10 : 54, 65, 76, 85, 101 : 25 : 276].';
MarkerSize = 5;
LineWidth = 2;
rLen = length(rVec_Simulation);
load('.\Data\RandomWayPointConstant_RateTime_Noiseless_Theory_Height_100.mat')
RateTime_Noiseless_Theory_Height_100 = RateTime_Noiseless_Theory;
load('.\Data\RandomWayPointConstant_RateTime_Noiseless_Theory_Height_150.mat')
RateTime_Noiseless_Theory_Height_150 = RateTime_Noiseless_Theory;
load('.\Data\RandomWayPointConstant_RateTime_Noiseless_Theory_Height_200.mat')
RateTime_Noiseless_Theory_Height_200 = RateTime_Noiseless_Theory;
load('.\Data\RandomWayPointConstant_RateTime_Noiseless_Simulation_Height_100.mat')
RateTime_Noiseless_Simulation_Height_100 = RateTime_Noiseless_Simulation;
load('.\Data\RandomWayPointConstant_RateTime_Noiseless_Simulation_Height_150.mat')
RateTime_Noiseless_Simulation_Height_150 = RateTime_Noiseless_Simulation;
load('.\Data\RandomWayPointConstant_RateTime_Noiseless_Simulation_Height_200.mat')
RateTime_Noiseless_Simulation_Height_200 = RateTime_Noiseless_Simulation;
figure(202)
grid on
hold on
plot(rVec_Simulation, repmat(RateTime_Noiseless_Simulation_Height_100(1), rLen, 1), 'g', 'LineWidth', LineWidth, 'LineStyle', '-.')
plot(rVec_Theory, RateTime_Noiseless_Theory_Height_100, 'b', 'LineWidth', LineWidth)
plot(rVec_Theory, RateTime_Noiseless_Simulation_Height_100(rVec_Theory), 'r', 'LineWidth', LineWidth, 'LineStyle', 'none', 'Marker', 'o', 'MarkerSize', MarkerSize)
plot(rVec_Simulation, repmat(RateTime_Noiseless_Simulation_Height_150(1), rLen, 1), 'g', 'LineWidth', LineWidth, 'LineStyle', '-.')
plot(rVec_Simulation, repmat(RateTime_Noiseless_Simulation_Height_200(1), rLen, 1), 'g', 'LineWidth', LineWidth, 'LineStyle', '-.')
plot(rVec_Theory, [RateTime_Noiseless_Theory_Height_150, RateTime_Noiseless_Theory_Height_200], 'b', 'LineWidth', LineWidth)
plot(rVec_Theory, [RateTime_Noiseless_Simulation_Height_150(rVec_Theory), RateTime_Noiseless_Simulation_Height_200(rVec_Theory)], 'r', 'LineWidth', LineWidth, 'LineStyle', 'none', 'Marker', 'o', 'MarkerSize', MarkerSize)
xlabel('Time (s)', 'interpreter', 'latex')
ylabel('Rate (b/s/Hz)', 'interpreter', 'latex')
s3 = gca;
set(s3, 'FontName', 'Times', 'FontSize', 14)
legend('UIM', 'UDM, Theory', 'UDM, Simulation')
legend3 = legend(s3);
set(legend3, 'Location', 'southeast', 'FontSize', 14, 'Interpreter', 'latex')
xlim([0, 276])
hold off