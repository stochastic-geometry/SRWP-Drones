%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Fundamentals of Drone Cellular Network Analysis under      %%%
%%%          Random Waypoint Mobility Model                             %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the simulation data for Fig. 3,     %%%
%%%   average rate in the SRWP mobility model.                          %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

datetime('now')
lambda0UAV = 1e-6;
R_UAV = 1e5;
NumUAV_Initial = lambda0UAV * pi * R_UAV ^ 2;
v = 45; % [km/h]
v = v / 3.6; % [m/s]
alpha = 3;
h = 100;%150;%200;%
P = 1;
MeanConstant = 250;
WaitConstant = 5;
dt = 1;%10;
tMax = 300;%600;
tVec = dt : dt : tMax;
tLen = length(tVec);
Realizations = 1e5;
SINR_Noiseless = zeros(Realizations, tLen + 1);
tic
parfor i = 1 : Realizations
    NumUAV = poissrnd(NumUAV_Initial);
    PosUAV_Range = unifrnd(0, 1, NumUAV, 1);
    PosUAV_Range = R_UAV * sqrt(PosUAV_Range);
    PosUAV_Theta = unifrnd(0, 2 * pi, NumUAV, 1);
    PosUAV = repmat(PosUAV_Range, 1, 2) .* [cos(PosUAV_Theta), sin(PosUAV_Theta)];
    [~, u0Ind] = min(PosUAV_Range);
    Interferers = setdiff(1 : NumUAV, u0Ind);
    RecoverTheta = pi + PosUAV_Theta(u0Ind);
    Temp_Noiseless = zeros(1, tLen + 1);
    DisplacedPosUAV = PosUAV;
    PosUAV3D = [DisplacedPosUAV, h * ones(NumUAV, 1)];
    DistanceUAV2UE = sqrt(sum(PosUAV3D .^ 2, 2));
    FadingUAV2UE = exprnd(1, NumUAV, tLen + 1);
    TotalPower = sum(P * FadingUAV2UE(:, 1) .* (DistanceUAV2UE .^ (-alpha)));
    ReceivedPower = P * FadingUAV2UE(u0Ind, 1) * (DistanceUAV2UE(u0Ind) ^ (-alpha));
    Interference = TotalPower - ReceivedPower;
    Temp_Noiseless(1) = ReceivedPower / Interference;
    it = 1;
    for t = tVec
        it = it + 1;
        n = ceil(v * t / (MeanConstant + v * WaitConstant));
        MovementDistVec = MeanConstant * ones(NumUAV, n);
        MovementThetaVec = unifrnd(0, 2 * pi, [NumUAV, n]);
        MovementThetaVec(u0Ind, :) = RecoverTheta;
        WaitTimeVec = WaitConstant * ones(NumUAV, n + 1);
        S = [zeros(NumUAV, 1), cumsum(MovementDistVec, 2)];
        W = cumsum(WaitTimeVec, 2);
        Y = S + v * W;
        RC = [zeros(NumUAV, 1), cumsum(MovementDistVec .* cos(MovementThetaVec), 2)];
        RS = [zeros(NumUAV, 1), cumsum(MovementDistVec .* sin(MovementThetaVec), 2)];
        for j = Interferers
            Y1 = Y(j, n);
            vd = max(v * t - Y1, 0) * [cos(MovementThetaVec(j, n)), sin(MovementThetaVec(j, n))];
            DisplacedPosUAV(j, :) = [PosUAV(j, 1) + RC(j, n) + vd(1), PosUAV(j, 2) + RS(j, n) + vd(2)];
        end
        if norm(DisplacedPosUAV(u0Ind, :)) >= v * dt
            DisplacedPosUAV(u0Ind, :) = PosUAV(u0Ind, :) + v * t * [cos(RecoverTheta), sin(RecoverTheta)];
        else
            DisplacedPosUAV(u0Ind, :) = [0, 0];
        end
        PosUAV3D = [DisplacedPosUAV, h * ones(NumUAV, 1)];
        DistanceUAV2UE = sqrt(sum(PosUAV3D .^ 2, 2));
        TotalPower = P * FadingUAV2UE(:, it).' * (DistanceUAV2UE .^ (-alpha));
        ReceivedPower = P * FadingUAV2UE(u0Ind, it) * (DistanceUAV2UE(u0Ind) ^ (-alpha));
        Interference = TotalPower - ReceivedPower;
        Temp_Noiseless(it) = ReceivedPower / Interference;
    end
    SINR_Noiseless(i, :) = Temp_Noiseless;
end
toc
RateTime_Noiseless_Simulation = mean(log(1 + SINR_Noiseless)).';
save(['RandomWayPointConstant_RateTime_Noiseless_Simulation_Height_', num2str(h)], 'RateTime_Noiseless_Simulation')
datetime('now')