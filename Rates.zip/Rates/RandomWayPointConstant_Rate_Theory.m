%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Fundamentals of Drone Cellular Network Analysis under      %%%
%%%          Random Waypoint Mobility Model                             %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the theoretical data for Fig. 3,    %%%
%%%   average rate in the SRWP mobility model.                          %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

datetime('now')
lambda0UAV = 1e-6;
v = 45; % [km/h]
v = v / 3.6; % [m/s]
MeanConstant = 250;
WaitConstant = 5;
% tVec = [4 : 10 : 54, 76 : 25 : 276].';
tVec = [4 : 10 : 54, 65, 76, 85, 101 : 25 : 276].';
tLen = length(tVec);
alpha = 3;
hVec = [100, 150, 200];
for h = hVec
    RateTime_Noiseless_Theory = zeros(tLen, 1);
    parfor it = 1 : tLen
        tic
        t = tVec(it);
        disp(t)
        MaxN = ceil(v * t / (MeanConstant + v * WaitConstant));
        InnerInt1 = @(gam, u0) arrayfun(@(gam, u0) Fun1(u0, gam, h, alpha, v, t, MaxN, MeanConstant, WaitConstant), gam, u0);
        InnerInt2 = @(gam, u0) arrayfun(@(gam, u0) Fun2(u0, gam, h, alpha, v, t, MaxN, MeanConstant, WaitConstant), gam, u0);
        fun01 = @(gam, u0) exp(-2 * pi * lambda0UAV * InnerInt1(gam, u0)) .* raylpdf(u0, 1 / sqrt(2 * pi * lambda0UAV)) ./ (1 + gam);
        fun02 = @(gam, u0) exp(-2 * pi * lambda0UAV * InnerInt2(gam, u0)) .* raylpdf(u0, 1 / sqrt(2 * pi * lambda0UAV)) ./ (1 + gam);
        fun1 = @(gam, u0) arrayfun(@(gam, u0) fun01(gam, u0), gam, u0);
        fun2 = @(gam, u0) arrayfun(@(gam, u0) fun02(gam, u0), gam, u0);
        q1 = integral2(fun1, 0, inf, 0, v * t, 'method', 'iterated', 'AbsTol', 1e-4, 'RelTol', 1e-3);
        q2 = integral2(fun2, 0, inf, v * t, inf, 'method', 'iterated', 'AbsTol', 1e-4, 'RelTol', 1e-3);
        q12 = real(q1 + q2);
        RateTime_Noiseless_Theory(it) = q12;
        toc
    end
    save(['RandomWayPointConstant_RateTime_Noiseless_Theory_Height_', num2str(h)], 'RateTime_Noiseless_Theory')
end
datetime('now')
function I = Fun1(u0, gam, h, alpha, v, t, MaxN, MeanConstant, WaitConstant)
q01 = RWPCons_intCDF_Approx_g1(u0, gam, h, alpha, v, t, MaxN, MeanConstant, WaitConstant);
q02 = RWPCons_intPDF_Approx_g1(u0, gam, h, alpha, v, t, MaxN, MeanConstant, WaitConstant);
g1 = @(ux) ux ./ (1 + 1 / gam * ((ux .^ 2 + h ^ 2) / h ^ 2) .^ (alpha / 2));
q03 = integral(g1, 0, inf);
I = q03 - q01 - q02;
end
function I = Fun2(u0, gam, h, alpha, v, t, MaxN, MeanConstant, WaitConstant)
q01 = RWPCons_intCDF_Approx_g2(u0, gam, h, alpha, v, t, MaxN, MeanConstant, WaitConstant);
q02 = RWPCons_intPDF_Approx_g2(u0, gam, h, alpha, v, t, MaxN, MeanConstant, WaitConstant);
g2 = @(ux) ux ./ (1 + 1 / gam * ((ux .^ 2 + h ^ 2) / ((u0 - v * t) .^ 2 + h ^ 2)) .^ (alpha / 2));
q03 = integral(g2, u0 - v * t, inf);
I = q03 - q01 - q02;
end