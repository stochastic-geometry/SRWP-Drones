function q02 = RWPCons_intPDF_Approx_g2(u0, gam, h, alpha, v, t, MaxN, MeanConstant, WaitConstant)
g2 = @(ux) ux ./ (1 + 1 / gam * ((ux .^ 2 + h ^ 2) / ((u0 - v * t) .^ 2 + h ^ 2)) .^ (alpha / 2));
n = MaxN - 1;
R0 = MeanConstant;
T0 = WaitConstant;
if t < T0 %% Wait 0
    q02 = 0;
elseif t < (R0 / v + T0) %% Flight 1
    s = v * t - v * T0;
    q02 = integral(@(ux) g2(ux) .* 1 / pi .* acos((s ^ 2 + ux .^ 2 - u0 ^ 2) ./ (2 * s * ux)), abs(u0 - s), u0 + s);
elseif t < (R0 / v + T0) + T0 %% Wait 1
    q02 = integral(@(ux) g2(ux) .* 1 / pi .* acos((R0 ^ 2 + ux .^ 2 - u0 ^ 2) ./ (2 * R0 * ux)), abs(u0 - R0), u0 + R0);
elseif t < 2 * (R0 / v + T0) %% Flight 2
    s = v * t - 2 * v * T0 - R0;
    uxMin = abs(u0 - R0) - s;
    uxMax = u0 + R0 + s;
    q02 = integral2(@(ux, l) g2(ux) .* 2 .* l ./ (pi * sqrt((l .^ 2 - (R0 - s) ^ 2) .* ((R0 + s) ^ 2 - l .^ 2))) .* 1 ./ pi .* acos((l .^ 2 + ux .^ 2 - u0 ^ 2) ./ (2 * l .* ux)), uxMin, uxMax, @(ux) max(abs(ux - u0), abs(R0 - s)), @(ux) min(min(v * t, ux + u0), R0 + s), 'method', 'iterated', 'AbsTol', 1e-4, 'RelTol', 1e-3);
elseif t < 2 * (R0 / v + T0) + T0 %% Wait 2
    uxMin = u0 - 2 * R0;
    uxMax = u0 + 2 * R0;
    q02 = integral2(@(ux, l) g2(ux) .* 2 ./ (pi * sqrt((2 * R0) ^ 2 - l .^ 2)) .* 1 ./ pi .* acos((l .^ 2 + ux .^ 2 - u0 ^ 2) ./ (2 * l .* ux)), uxMin, uxMax, @(ux) abs(ux - u0), @(ux) min(min(v * t, ux + u0), 2 * R0), 'method', 'iterated', 'AbsTol', 1e-4, 'RelTol', 1e-3);
elseif t < 3 * (R0 / v + T0) %% Flight 3
    s = v * t - 3 * v * T0 - 2 * R0;
    uxMin = u0 - (2 * R0 + s);
    uxMax = u0 + (2 * R0 + s);
    q02 = integral3(@(ux, l, z) g2(ux) .* 2 ./ (pi * sqrt((2 * R0) ^ 2 - z .^ 2)) .* 2 .* l ./ (pi * sqrt((l .^ 2 - (z - s) .^ 2) .* ((z + s) .^ 2 - l .^ 2))) .* 1 ./ pi .* acos((l .^ 2 + ux .^ 2 - u0 ^ 2) ./ (2 * l .* ux)), uxMin, uxMax, @(ux) abs(ux - u0), @(ux) min(v * t, ux + u0), @(ux, l) abs(l - s), @(ux, l) min(2 * R0, l + s), 'method', 'iterated', 'AbsTol', 1e-4, 'RelTol', 1e-3);
elseif (t >= n * (R0 / v + T0)) && (t < n * (R0 / v + T0) + T0) %% Wait n
    uxMin = u0 - n * R0;
    uxMax = u0 + n * R0;
    q02 = integral2(@(ux, l) g2(ux) .* (2 .* l ./ (n * R0 ^ 2) .* exp(-l .^ 2 / (n * R0 ^ 2))) ./ (1 - exp(-n)) .* 1 ./ pi .* acos((l .^ 2 + ux .^ 2 - u0 ^ 2) ./ (2 * l .* ux)), uxMin, uxMax, @(ux) abs(ux - u0), @(ux) min(min(v * t, ux + u0), n * R0), 'method', 'iterated', 'AbsTol', 1e-4, 'RelTol', 1e-3);
elseif (t >= n * (R0 / v + T0) + T0) && (t < (n + 1) * (R0 / v + T0)) %% Flight n + 1
    s = v * t - (n + 1) * v * T0 - n * R0;
    uxMin = u0 - (n * R0 + s);
    uxMax = u0 + (n * R0 + s);
    q02 = integral3(@(ux, l, z) g2(ux) .* (2 .* z ./ (n * R0 ^ 2) .* exp(-z .^ 2 / (n * R0 ^ 2))) ./ (1 - exp(-n)) .* 2 .* l ./ (pi * sqrt((l .^ 2 - (z - s) .^ 2) .* ((z + s) .^ 2 - l .^ 2))) .* 1 ./ pi .* acos((l .^ 2 + ux .^ 2 - u0 ^ 2) ./ (2 * l .* ux)), uxMin, uxMax, @(ux) abs(ux - u0), @(ux) min(v * t, ux + u0), @(ux, l) abs(l - s), @(ux, l) min(n * R0, l + s), 'method', 'iterated', 'AbsTol', 1e-4, 'RelTol', 1e-3);
end