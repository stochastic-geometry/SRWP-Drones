function B = RWPCons_PDF(ux, t, u0, MaxN, v, MeanConstant, WaitConstant)
n = MaxN;
R0 = MeanConstant;
T0 = WaitConstant;
if t <= T0 %% Wait 0
    B = 0;
elseif (t > T0) && (t <= (R0 / v + T0)) %% Flight 1
    s = v * t - v * T0;
    if (s > abs(ux - u0)) && (s <= min(v * t, ux + u0))
        B = 1 / pi * acos((s ^ 2 + ux ^ 2 - u0 ^ 2) / (2 * s * ux));
    else
        B = 0;
    end
elseif (t > (R0 / v + T0)) && (t <= (R0 / v + T0) + T0) %% Wait 1
    if (R0 > abs(ux - u0)) && (R0 < min(v * t, ux + u0))
        B = 1 / pi * acos((R0 ^ 2 + ux ^ 2 - u0 ^ 2) / (2 * R0 * ux));
    else
        B = 0;
    end
elseif (t > (R0 / v + T0) + T0) && (t <= 2 * (R0 / v + T0)) %% Flight 2
    s = v * t - 2 * v * T0 - R0;
    if (R0 + s <= abs(ux - u0)) || (min(v * t, ux + u0) <= abs(R0 - s))
        B = 0;
    else
        B = integral(@(l) 2 * l ./ (pi * sqrt((l .^ 2 - (R0 - s) ^ 2) .* ((R0 + s) ^ 2 - l .^ 2))) .* 1 ./ pi .* acos((l .^ 2 + ux ^ 2 - u0 ^ 2) ./ (2 * l * ux)), max(abs(R0 - s), abs(ux - u0)), min(R0 + s, min(v * t, ux + u0)));
    end
elseif (t > 2 * (R0 / v + T0)) && (t <= 2 * (R0 / v + T0) + T0) %% Wait 2
    if 2 * R0 <= abs(ux - u0)
        B = 0;
    else
        B = integral(@(l) 2 ./ (pi * sqrt((2 * R0) ^ 2 - l .^ 2)) .* 1 ./ pi .* acos((l .^ 2 + ux ^ 2 - u0 ^ 2) ./ (2 * l * ux)), abs(ux - u0), min(2 * R0, min(v * t, ux + u0)));
    end
elseif (t > 2 * (R0 / v + T0) + T0) && (t <= 3 * (R0 / v + T0)) %% Flight 3
    s = v * t - 3 * v * T0 - 2 * R0;
    if abs(ux - u0) < s + 2 * R0
        B = integral2(@(l, z) 2 ./ (pi * sqrt((2 * R0) ^ 2 - z .^ 2)) .* 2 .* l ./ (pi * sqrt((l .^ 2 - (z - s) .^ 2) .* ((z + s) .^ 2 - l .^ 2))) .* 1 ./ pi .* acos((l .^ 2 + ux ^ 2 - u0 ^ 2) ./ (2 * l * ux)), abs(ux - u0), min(min(v * t, ux + u0), s + 2 * R0), @(l) abs(l - s), @(l) min(l + s, 2 * R0), 'AbsTol', 1e-4, 'RelTol', 1e-4);
    else
        B = 0;
    end
elseif (t >= n * (R0 / v + T0)) && (t <= n * (R0 / v + T0) + T0) %% Wait n
    if n * R0 <= abs(ux - u0)
        B = 0;
    else
        B = integral(@(l) (2 * l ./ (n * R0 ^ 2) .* exp(-l .^ 2 / (n * R0 ^ 2))) ./ (1 - exp(-n)) .* 1 ./ pi .* acos((l .^ 2 + ux ^ 2 - u0 ^ 2) ./ (2 * l * ux)), abs(ux - u0), min(n * R0, min(v * t, ux + u0)));
    end
elseif (t > n * (R0 / v + T0) + T0) && (t <= (n + 1) * (R0 / v + T0)) %% Flight n + 1
    s = v * t - (n + 1) * v * T0 - n * R0;
    if abs(ux - u0) < s + n * R0
        B = integral2(@(l, z) (2 * z ./ (n * R0 ^ 2) .* exp(-z .^ 2 / (n * R0 ^ 2))) ./ (1 - exp(-n)) .* 2 .* l ./ (pi * sqrt((l .^ 2 - (z - s) .^ 2) .* ((z + s) .^ 2 - l .^ 2))) .* 1 ./ pi .* acos((l .^ 2 + ux ^ 2 - u0 ^ 2) ./ (2 * l * ux)), abs(ux - u0), min(min(v * t, ux + u0), s + n * R0), @(l) abs(l - s), @(l) min(l + s, n * R0));
    else
        B = 0;
    end
end
% if MaxN == 1
%     if (MeanConstant >= abs(ux - u0)) && (MeanConstant <= min(ux + u0, v * t))
%         B = 1 / pi * acos((MeanConstant ^ 2 + ux ^ 2 - u0 ^ 2) / (2 * MeanConstant * ux));
%     else
%         B = 0;
%     end
% elseif MaxN == 2
%     if 2 * MeanConstant > abs(ux - u0)
%         B = integral(@(l) 2 ./ (pi * sqrt((2 * MeanConstant) ^ 2 - l .^ 2)) .* 1 / pi .* acos((l .^ 2 + ux ^ 2 - u0 ^ 2) ./ (2 * l * ux)), abs(ux - u0), min([ux + u0, v * t, 2 * MeanConstant]));
%     else
%         B = 0;
%     end
% else
%     if MaxN * MeanConstant > abs(ux - u0)
%         B = integral(@(l) 2 * l ./ (MaxN * MeanConstant ^ 2 * (1 - exp(-MaxN))) .* exp(-l .^ 2 / (MaxN * MeanConstant ^ 2)) .* 1 / pi .* acos((l .^ 2 + ux ^ 2 - u0 ^ 2) ./ (2 * l * ux)), abs(ux - u0), min([ux + u0, v * t, MaxN * MeanConstant]));
%     else
%         B = 0;
%     end
% end