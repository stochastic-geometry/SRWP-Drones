function A = RWPCons_CDF(x, t, MaxN, v, MeanConstant, WaitConstant)
n = MaxN;
R0 = MeanConstant;
T0 = WaitConstant;
if x <= 0
    A = 0;
    return;
elseif x >= v * t
    A = 1;
    return;
end
if t <= T0 %% Wait 0
    A = 1;
elseif (t > T0) && (t <= (R0 / v + T0)) %% Flight 1
    s = v * t - v * T0;
    if x >= s
        A = 1;
    else
        A = 0;
    end
elseif (t > (R0 / v + T0)) && (t <= (R0 / v + T0) + T0) %% Wait 1
    if x >= R0
        A = 1;
    else
        A = 0;
    end
elseif (t > (R0 / v + T0) + T0) && (t <= 2 * (R0 / v + T0)) %% Flight 2
    s = v * t - 2 * v * T0 - R0;
    if x >= R0 + s
        A = 1;
    elseif (x < R0 + s) && (x >= abs(R0 - s))
        A = 1 / pi * acos((R0 ^ 2 + s ^ 2 - x ^ 2) / (2 * R0 * s));
    else
        A = 0;
    end
elseif (t > 2 * (R0 / v + T0)) && (t <= 2 * (R0 / v + T0) + T0) %% Wait 2
    if x >= 2 * R0
        A = 1;
    else
        A = 2 / pi * asin(x / (2 * R0));
    end
elseif (t > 2 * (R0 / v + T0) + T0) && (t <= 3 * (R0 / v + T0)) %% Flight 3
    s = v * t - 3 * v * T0 - 2 * R0;
    if x >= 2 * R0 + s
        A = 1;
    else
        A = 2 / pi * asin(max(x - s, 0) / (2 * R0)) + integral(@(z) 1 / pi * acos((z .^ 2 + s ^ 2 - x ^ 2) ./ (2 * z * s)) .* 2 ./ (pi * sqrt((2 * R0) ^ 2 - z .^ 2)), abs(x - s), min(x + s, 2 * R0));
    end
elseif (t >= n * (R0 / v + T0)) && (t <= n * (R0 / v + T0) + T0) %% Wait n
    if x >= n * R0
        A = 1;
    else
        A = (1 - exp(-x ^ 2 / (n * R0 ^ 2))) / (1 - exp(-n));
    end
elseif (t > n * (R0 / v + T0) + T0) && (t <= (n + 1) * (R0 / v + T0)) %% Flight n + 1
    s = v * t - (n + 1) * v * T0 - n * R0;
    if x >= n * R0 + s
        A = 1;
    else
        A = (1 - exp(-(max(x - s, 0)) ^ 2 / (n * R0 ^ 2))) / (1 - exp(-n)) + integral(@(z) 1 / pi * acos((z .^ 2 + s ^ 2 - x ^ 2) ./ (2 * z * s)) .* 2 .* z .* exp(-z .^ 2 / (n * R0 ^ 2)) / (n * R0 ^ 2 * (1 - exp(-n))), abs(x - s), min(x + s, n * R0));
    end
end
% if MaxN == 1
%     if x > MeanConstant
%         A = 1;
%     else
%         A = 0;
%     end
% elseif MaxN == 2
%     A = 2 / pi * asin(x / (2 * MeanConstant));
% else
%     A = (1 - exp(-x ^ 2 / (MaxN * MeanConstant ^ 2))) / (1 - exp(-MaxN));
% end