%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Fundamentals of Drone Cellular Network Analysis under      %%%
%%%          Random Waypoint Mobility Model                             %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the plot of Fig. 2, density of      %%%
%%%   the network of interferers in the SRWP mobility model.            %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ClipData1 = 3000;
load('.\Data\RandomWayPointConstant_Density_Simulation.mat')
load('.\Data\RandomWayPointConstant_Density_Theory.mat')
Density_Simulation = Density_Simulation(:, 1 : ClipData1);
Density_Theory = Density_Theory(:, 1 : ClipData1);
rVec1 = (1 : ClipData1).';
rVecDS = [100 : 200 : 500, 800, 1000, 1300 : 300 : ClipData1];
MarkerSize = 5;
LineWidth = 2;
figure(201)
s1 = gca;
hold on
plot(rVec1, Density_Theory(1, :).', 'b', 'LineWidth', LineWidth)
plot(rVecDS, Density_Simulation(1, rVecDS).', 'r', 'LineWidth', LineWidth, 'LineStyle', 'none', 'Marker', 'o', 'MarkerSize', MarkerSize)
plot(rVec1, Density_Theory(2 : 4, :).', 'b', 'LineWidth', LineWidth)
plot(rVecDS, Density_Simulation(2 : 4, rVecDS).', 'r', 'LineWidth', LineWidth, 'LineStyle', 'none', 'Marker', 'o', 'MarkerSize', MarkerSize)
xlabel('u_x (m)', 'FontName', 'Times', 'FontSize', 12)
ylabel('\lambda(u_x, u_0, t)', 'FontName', 'Times', 'FontSize', 12)
set(s1, 'FontName', 'Times', 'FontSize', 12)
legend('Theory', 'Simulation')
legend1 = legend(s1);
set(legend1, 'Location', 'southeast', 'FontSize', 12, 'Interpreter', 'latex')
ylim([0, 1.05e-6])
hold off
grid on