%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Fundamentals of Drone Cellular Network Analysis under      %%%
%%%          Random Waypoint Mobility Model                             %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the theoretical data for Fig. 2,    %%%
%%%   density of the network of interferers in the SRWP mobility model. %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

datetime('now')
lambda0UAV = 1e-6;
R_UAV = 1e4;
NumUAV_Initial = lambda0UAV * pi * R_UAV ^ 2;
v = 45; % [km/h]
v = v / 3.6; % [m/s]
dr = 1;%10;%
NumR = round((R_UAV - dr) / dr) + 1;
MeanConstant = 250;%sigmaRayleigh = 500 * sqrt(2 / pi);%muExp = 500;%
u0 = 500;
WaitConstant = 5;%muExpTime = 5;%
tVec = [40, 70, 170, 300];%[10, 20, 27, 40, 54, 70, 150, 160, 170, 201]; % Condition: v * t < R_UAV
tLen = length(tVec);
Density_Theory = zeros(tLen, NumR);
for T = 1 : tLen
    tic
    t = tVec(T);
    MaxN = floor(t / (MeanConstant / v + WaitConstant));
    disp(['TimeTime: ', num2str(t)])
    rVec1 = dr : dr : round(abs(u0 - v * t));
    rLen1 = length(rVec1);
    if u0 < v * t
        for R = 1 : rLen1
            ux = rVec1(R);
            A = RWPCons_CDF(u0 - ux, t, MaxN, v, MeanConstant, WaitConstant);
            B = RWPCons_PDF(ux, t, u0, MaxN, v, MeanConstant, WaitConstant);
            Density_Theory(T, R) = lambda0UAV * (1 - A - B);
        end
    end
    rVec2 = round(abs(u0 - v * t) + dr) : dr : round(u0 + v * t - dr);
    rLen2 = length(rVec2);
    for R = rLen1 + 1 : rLen1 + rLen2
        ux = rVec2(R - rLen1);
        if u0 - ux >= v * t
            A = 1;
            B = 0;
        elseif u0 - ux <= 0
            A = 0;
            B = RWPCons_PDF(ux, t, u0, MaxN, v, MeanConstant, WaitConstant);
        else
            A = RWPCons_CDF(u0 - ux, t, MaxN, v, MeanConstant, WaitConstant);
            B = RWPCons_PDF(ux, t, u0, MaxN, v, MeanConstant, WaitConstant);
        end
        Density_Theory(T, R) = lambda0UAV * (1 - A - B);
    end
    rVec3 = round(u0 + v * t) : dr : round(R_UAV);
    rLen3 = length(rVec3);
    for R = rLen1 + rLen2 + 1 : rLen1 + rLen2 + rLen3
        % ux = rVec3(R - (rLen1 + rLen2));
        Density_Theory(T, R) = lambda0UAV;
    end
    toc
end
save('RandomWayPointConstant_Density_Theory', 'Density_Theory')
datetime('now')