%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Fundamentals of Drone Cellular Network Analysis under      %%%
%%%          Random Waypoint Mobility Model                             %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the simulation data for Fig. 2,     %%%
%%%   density of the network of interferers in the SRWP mobility model. %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

datetime('now')
lambda0UAV = 1e-6;
R_UAV = 1e4;
NumUAV_Initial = lambda0UAV * pi * R_UAV ^ 2;
v = 45; % [km/h]
v = v / 3.6; % [m/s]
dr = 1;%10;%
NumR = round((R_UAV - dr) / dr) + 1;
MeanConstant = 250;%sigmaRayleigh = 500 * sqrt(2 / pi);%muExp = 500;%
u0 = 500;
WaitConstant = 5;%muExpTime = 5;%
tVec = [40, 70, 170, 300];%[10, 20, 27, 40, 54, 70, 150, 160, 170, 201]; % Condition: v * t < R_UAV
tLen = length(tVec);
CountPointsAll = zeros(tLen, NumR);
Realizations = 1e8;
tic
ierr = 0;
parfor i = 1 : Realizations
    CountPoints = zeros(tLen, NumR);
    NumUAV = poissrnd(NumUAV_Initial);
    PosUAV_Range = unifrnd(0, 1, NumUAV, 1);
    PosUAV_Range = R_UAV * sqrt(PosUAV_Range);
    PosUAV_Theta = unifrnd(0, 2 * pi, NumUAV, 1);
    f = PosUAV_Range <= u0;
    PosUAV_Range(f) = [];
    PosUAV_Theta(f) = [];
    NumUAV = length(PosUAV_Range);
    PosUAV = repmat(PosUAV_Range, 1, 2) .* [cos(PosUAV_Theta), sin(PosUAV_Theta)];
    kk = 0;
    for t = tVec
        kk = kk + 1;
        MaxN = ceil(v * t / (MeanConstant + v * WaitConstant));
        WaitTimeVec = WaitConstant * ones(NumUAV, MaxN + 1);%exprnd(muExpTime, [NumUAV, MaxN + 1]);%
        MovementDistVec = MeanConstant * ones(NumUAV, MaxN);%raylrnd(sigmaRayleigh, [NumUAV, MaxN]);%exprnd(mu, [NumUAV, MaxN]);%
        MovementThetaVec = unifrnd(0, 2 * pi, [NumUAV, MaxN]);
        S = [zeros(NumUAV, 1), cumsum(MovementDistVec, 2)];
        W = cumsum(WaitTimeVec, 2);
        M = [zeros(NumUAV, 1), S(:, 2 : end) + v * W(:, 1 : end - 1)];
        Y = S + v * W;
        RC = [zeros(NumUAV, 1), cumsum(MovementDistVec .* cos(MovementThetaVec), 2)];
        RS = [zeros(NumUAV, 1), cumsum(MovementDistVec .* sin(MovementThetaVec), 2)];
        RangeVec = zeros(NumUAV, 1);
        for j = 1 : NumUAV
            for n = 1 : MaxN
                M1 = M(j, n);
                M2 = M(j, n + 1);
                Y1 = Y(j, n);
                if (v * t >= M1) && (v * t < Y1) % Waiting Period
                    DisplacedPosUAV = [PosUAV(j, 1) + RC(j, n), PosUAV(j, 2) + RS(j, n)];
                    RangeVec(j) = sqrt(DisplacedPosUAV(1) ^ 2 + DisplacedPosUAV(2) ^ 2);
                    break;
                elseif (v * t >= Y1) && (v * t <= M2) % Flight Period
                    vd = (v * t - Y1) * [cos(MovementThetaVec(j, n)), sin(MovementThetaVec(j, n))];
                    DisplacedPosUAV = [PosUAV(j, 1) + RC(j, n) + vd(1), PosUAV(j, 2) + RS(j, n) + vd(2)];
                    RangeVec(j) = sqrt(DisplacedPosUAV(1) ^ 2 + DisplacedPosUAV(2) ^ 2);
                    break;
                end
                if n == MaxN % In case MaxN is not large enough
                    RangeVec(j) = max(1, sum(RangeVec(1 : j - 1)) / j);
                    ierr = ierr + 1;
                end
            end
        end
        SlottedRange = ceil(RangeVec / dr);
        [a, b] = hist(SlottedRange, unique(SlottedRange));
        CountPoints(kk, b) = a;
    end
    CountPoints = CountPoints(:, 1 : NumR);
    CountPointsAll = CountPointsAll + CountPoints;
end
toc
AreaAnnulus = pi * (2 * (0 : dr : R_UAV - dr) * dr + dr ^ 2);
CountPointsAll = CountPointsAll / Realizations;
Density_Simulation = CountPointsAll ./ repmat(AreaAnnulus, tLen, 1);
save('RandomWayPointConstant_Density_Simulation.mat', 'Density_Simulation')
datetime('now')